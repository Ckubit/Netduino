using System;
using Microsoft.SPOT;
using Microsoft.SPOT.Input;
using Microsoft.SPOT.Hardware;
using Microsoft.SPOT.Presentation;
using Microsoft.SPOT.Presentation.Controls;
using EmbeddedFusion.SPOT.Hardware;
using System.Threading;

namespace ServoControl
{
    public class Program : Microsoft.SPOT.Application
    {
        public static void Main()
        {
            Program myApplication = new Program();

            Window mainWindow = myApplication.CreateWindow();

            // Create the object that configures the GPIO pins to buttons.
            GPIOButtonInputProvider inputProvider = new GPIOButtonInputProvider(null);

            // Start the application
            myApplication.Run(mainWindow);
        }

        private Window mainWindow;

        private OutputPort servoPort;      

        public Window CreateWindow()
        {
            // Create a window object and set its size to the
            // size of the display.
            mainWindow = new Window();
            mainWindow.Height = SystemMetrics.ScreenHeight;
            mainWindow.Width = SystemMetrics.ScreenWidth;

            // Create a single text control.
            Text text = new Text();

            text.Font = Resources.GetFont(Resources.FontResources.small);
            text.TextContent = Resources.GetString(Resources.StringResources.String1);
            text.HorizontalAlignment = Microsoft.SPOT.Presentation.HorizontalAlignment.Center;
            text.VerticalAlignment = Microsoft.SPOT.Presentation.VerticalAlignment.Center;

            // Add the text control to the window.
            mainWindow.Child = text;

            // Connect the button handler to all of the buttons.
            mainWindow.AddHandler(Buttons.ButtonDownEvent, new ButtonEventHandler(OnButtonDown), false);

            // Set the window visibility to visible.
            mainWindow.Visibility = Visibility.Visible;

            // Attach the button focus to the window.
            Buttons.Focus(mainWindow);

            servoPort = new OutputPort(Meridian.Pins.GPIO1, false);

            return mainWindow;
        }

        private void OnButtonDown(object sender, ButtonEventArgs e)
        {
            int pulseWidth = 1250;

            switch (e.Button)
            {
                // -90 Degrees
                case Button.Left:
                    pulseWidth = 400;
                    break;

                // 0 Degrees
                case Button.Select:
                    pulseWidth = 1250;
                    break;

                // +90 Degrees
                case Button.Right:
                    pulseWidth = 2150;
                    break;
            }

            MoveServo(pulseWidth);
        }

        /// <summary>
        /// Moves servo by given pulse width
        /// </summary>
        /// <param name="pulseWidth">pulsewidth for PWM</param>
        private void MoveServo(int pulseWidth)
        {
            // Maximum time for pulse is 25000 microsec.
            int pause = 25000 - pulseWidth;

            for (int i = 0; i < 30; i++)
            {
                servoPort.Write(true);
                DelayMicroSec(pulseWidth);
                servoPort.Write(false);

                DelayMicroSec(pause);
            }
        }

        /// <summary>
        /// Blocks thread for given number of microseconds
        /// </summary>
        /// <param name="microSeconds">Delay in microseconds</param>
        private void DelayMicroSec(int microSeconds)
        {
            DateTime startTime = DateTime.Now;
            
            int stopTicks = microSeconds * 10;

            TimeSpan divTime = DateTime.Now - startTime;
            while (divTime.Ticks < stopTicks)
            { 
                divTime = DateTime.Now - startTime; 
            }
        }
        
    }
}
